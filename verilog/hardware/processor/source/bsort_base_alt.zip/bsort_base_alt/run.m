newnode		riscv
sizemem		65536	
srecl		"bsort-sf.sr"
run
on
