volatile unsigned int * gDebugLedsMemoryMappedRegister = (unsigned int *)0x2000;
